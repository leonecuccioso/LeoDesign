
import { storage } from "./storage";
import { scrypt, randomBytes } from "crypto";
import { promisify } from "util";

const scryptAsync = promisify(scrypt);

async function hashPassword(password: string) {
  const salt = randomBytes(16).toString("hex");
  const buf = (await scryptAsync(password, salt, 64)) as Buffer;
  return `${buf.toString("hex")}.${salt}`;
}

async function createAdminUser() {
  try {
    // Verifica se esiste già l'utente leonard
    const existingUser = await storage.getUserByUsername("leonard");
    if (existingUser) {
      console.log("L'utente leonard esiste già. Aggiornamento password...");
      // Aggiorna la password dell'utente esistente
      await storage.updateUserPassword(existingUser.id, await hashPassword("leonard2"));
      console.log("Password aggiornata con successo!");
    } else {
      // Crea un nuovo utente amministratore
      const newUser = await storage.createUser({
        username: "leonard",
        password: await hashPassword("leonard2"),
        isAdmin: true
      });
      console.log("Nuovo utente amministratore creato:", newUser);
    }

    // Controlla se esiste l'utente admin e lo rimuove
    const adminUser = await storage.getUserByUsername("admin");
    if (adminUser) {
      await storage.deleteUser(adminUser.id);
      console.log("Utente admin rimosso con successo!");
    }

    console.log("Operazione completata!");
  } catch (error) {
    console.error("Errore durante la creazione dell'utente amministratore:", error);
  } finally {
    // Chiudi la connessione al database
    await storage.close();
  }
}

// Esegui la funzione
createAdminUser();
