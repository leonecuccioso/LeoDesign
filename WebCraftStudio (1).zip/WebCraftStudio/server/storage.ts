import { users, type User, type InsertUser, requests, type Request, type InsertRequest } from "@shared/schema";
import session from "express-session";
import createMemoryStore from "memorystore";
const MemoryStore = createMemoryStore(session);

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  createRequest(request: InsertRequest & { ipAddress: string }): Promise<Request>;
  getRequests(): Promise<Request[]>;
  updateRequestStatus(id: number, status: string): Promise<Request | undefined>;
  updateUserPassword(userId: number, hashedPassword: string): Promise<User | undefined>; // Added
  deleteUser(userId: number): Promise<User | undefined>; // Added
  sessionStore: session.SessionStore;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private requests: Map<number, Request>;
  private currentUserId: number;
  private currentRequestId: number;
  sessionStore: session.SessionStore;

  constructor() {
    this.users = new Map();
    this.requests = new Map();
    this.currentUserId = 1;
    this.currentRequestId = 1;
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000,
    });

    // Create the new admin user
    this.createUser({ username: "leonard", password: this.hashPassword("leonard2"), isAdmin: true });
    // Delete the old admin user
    this.deleteUser(1);


  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { ...insertUser, id, isAdmin: false };
    this.users.set(id, user);
    return user;
  }

  async createRequest(request: InsertRequest & { ipAddress: string }): Promise<Request> {
    const id = this.currentRequestId++;
    const newRequest: Request = {
      ...request,
      id,
      status: "pending",
      createdAt: new Date(),
    };
    this.requests.set(id, newRequest);
    return newRequest;
  }

  async getRequests(): Promise<Request[]> {
    return Array.from(this.requests.values()).sort((a, b) => 
      b.createdAt.getTime() - a.createdAt.getTime()
    );
  }

  async updateRequestStatus(id: number, status: string): Promise<Request | undefined> {
    const request = this.requests.get(id);
    if (!request) return undefined;

    const updatedRequest = { ...request, status };
    this.requests.set(id, updatedRequest);
    return updatedRequest;
  }

  async updateUserPassword(userId: number, hashedPassword: string): Promise<User | undefined> {
    const user = this.users.get(userId);
    if (!user) return undefined;
    const updatedUser = {...user, password: hashedPassword};
    this.users.set(userId, updatedUser);
    return updatedUser;
  }

  async deleteUser(userId: number): Promise<User | undefined> {
    const user = this.users.get(userId);
    if (!user) return undefined;
    this.users.delete(userId);
    return user;
  }

  // Simple password hashing (replace with a stronger hashing algorithm in production)
  private hashPassword(password: string): string {
    //  This is a placeholder.  Use bcrypt or similar in production.
    return password + ".hashed";
  }
}

export const storage = new MemStorage();