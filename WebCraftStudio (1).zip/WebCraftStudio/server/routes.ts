import type { Express } from "express";
import { createServer, type Server } from "http";
import { setupAuth } from "./auth";
import { storage } from "./storage";
import { insertRequestSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  setupAuth(app);

  app.post("/api/requests", async (req, res) => {
    try {
      const data = insertRequestSchema.parse(req.body);
      const ipAddress = req.ip;
      
      const request = await storage.createRequest({
        ...data,
        ipAddress,
      });

      res.status(201).json(request);
    } catch (error) {
      res.status(400).json({ error: "Invalid request data" });
    }
  });

  app.get("/api/requests", async (req, res) => {
    if (!req.isAuthenticated() || !req.user?.isAdmin) {
      return res.status(403).json({ error: "Unauthorized" });
    }

    const requests = await storage.getRequests();
    res.json(requests);
  });

  app.patch("/api/requests/:id/status", async (req, res) => {
    if (!req.isAuthenticated() || !req.user?.isAdmin) {
      return res.status(403).json({ error: "Unauthorized" });
    }

    const { id } = req.params;
    const { status } = req.body;

    if (!["pending", "approved", "rejected"].includes(status)) {
      return res.status(400).json({ error: "Invalid status" });
    }

    const request = await storage.updateRequestStatus(parseInt(id), status);
    if (!request) {
      return res.status(404).json({ error: "Request not found" });
    }

    res.json(request);
  });

  const httpServer = createServer(app);
  return httpServer;
}
