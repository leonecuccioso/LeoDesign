import { createTransport } from "nodemailer";
import type { Request } from "@shared/schema";

// Create reusable transporter using SMTP settings
const transporter = createTransport({
  host: process.env.SMTP_HOST || "smtp.gmail.com",
  port: parseInt(process.env.SMTP_PORT || "587"),
  secure: process.env.SMTP_SECURE === "true",
  auth: {
    user: process.env.SMTP_USER || "",
    pass: process.env.SMTP_PASS || "",
  },
});

export async function sendRequestNotification(request: Request) {
  try {
    // Email to admin
    await transporter.sendMail({
      from: process.env.SMTP_FROM || "noreply@example.com",
      to: process.env.ADMIN_EMAIL || "admin@example.com",
      subject: "New Website Commission Request",
      html: `
        <h2>New Commission Request</h2>
        <p><strong>From:</strong> ${request.name} (${request.email})</p>
        <p><strong>Budget:</strong> ${request.budget}</p>
        <p><strong>Description:</strong></p>
        <p>${request.description}</p>
        <p><strong>IP Address:</strong> ${request.ipAddress}</p>
        <p><strong>Submitted:</strong> ${request.createdAt.toLocaleString()}</p>
      `,
    });

    // Confirmation email to client
    await transporter.sendMail({
      from: process.env.SMTP_FROM || "noreply@example.com",
      to: request.email,
      subject: "Thank You for Your Website Commission Request",
      html: `
        <h2>Thank You for Your Request</h2>
        <p>Dear ${request.name},</p>
        <p>We have received your website commission request and will review it shortly.</p>
        <p>Here's a summary of your request:</p>
        <ul>
          <li><strong>Budget Range:</strong> ${request.budget}</li>
          <li><strong>Project Description:</strong> ${request.description}</li>
        </ul>
        <p>We'll get back to you soon with our response.</p>
        <p>Best regards,<br>The Web Design Team</p>
      `,
    });

    return true;
  } catch (error) {
    console.error("Email sending error:", error);
    return false;
  }
}

export async function sendStatusUpdateNotification(request: Request) {
  try {
    const statusMessages = {
      approved: "has been approved",
      rejected: "has been declined",
      pending: "is under review",
    };

    await transporter.sendMail({
      from: process.env.SMTP_FROM || "noreply@example.com",
      to: request.email,
      subject: `Website Commission Request Update`,
      html: `
        <h2>Request Status Update</h2>
        <p>Dear ${request.name},</p>
        <p>Your website commission request ${statusMessages[request.status as keyof typeof statusMessages]}.</p>
        ${request.status === "approved" ? `
        <p>We will contact you shortly to discuss the next steps and begin the development process.</p>
        ` : request.status === "rejected" ? `
        <p>Unfortunately, we are unable to proceed with your request at this time. This could be due to our current workload or project requirements.</p>
        ` : `
        <p>We are currently reviewing your request and will provide an update soon.</p>
        `}
        <p>Best regards,<br>The Web Design Team</p>
      `,
    });

    return true;
  } catch (error) {
    console.error("Email sending error:", error);
    return false;
  }
}
