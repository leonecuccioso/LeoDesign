import { Link } from "wouter";

export function Footer() {
  return (
    <footer className="border-t border-primary/10 bg-background/80 backdrop-blur-sm">
      <div className="container mx-auto px-4 py-8">
        <div className="flex flex-col items-center justify-center space-y-4 text-center">
          <div className="text-2xl font-bold bg-gradient-to-r from-primary to-primary/60 bg-clip-text text-transparent">
            Leonard Design
          </div>
          <p className="text-sm text-muted-foreground">
            Trasformo le tue idee in realtà digitali
          </p>
          <p className="text-xs text-muted-foreground">
            © {new Date().getFullYear()} Leonard Design. Tutti i diritti riservati.
          </p>
        </div>
      </div>
    </footer>
  );
}
