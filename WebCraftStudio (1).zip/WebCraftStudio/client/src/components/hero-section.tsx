import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";
import { Code2, Rocket, Sparkles } from "lucide-react";
import { useTranslation } from "react-i18next";

export function HeroSection() {
  const { t } = useTranslation();

  return (
    <div className="relative min-h-screen">
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-primary/10 via-background to-background pointer-events-none" />
      <div className="relative pt-32 pb-20 container mx-auto px-4">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="max-w-4xl mx-auto text-center space-y-8"
        >
          <motion.div
            initial={{ scale: 0.9 }}
            animate={{ scale: 1 }}
            transition={{ duration: 0.5 }}
            className="text-5xl md:text-7xl font-bold text-foreground"
          >
            {t('hero.title')}
          </motion.div>

          <motion.p 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.3 }}
            className="text-xl text-foreground"
          >
            {t('hero.subtitle')}
            <br />
            {t('hero.description')}
          </motion.p>

          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 }}
            className="grid grid-cols-1 sm:grid-cols-1 gap-6 max-w-xl mx-auto"
          >
            <a href="#request-form">
              <Button 
                size="lg" 
                className="w-full bg-primary hover:bg-primary/90 group transition-all duration-300"
              >
                <span className="relative inline-flex items-center">
                  {t('hero.cta')}
                  <Rocket className="ml-2 h-4 w-4 group-hover:translate-x-1 transition-transform" />
                </span>
              </Button>
            </a>
          </motion.div>

          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.7 }}
            className="pt-16 grid grid-cols-1 md:grid-cols-3 gap-8 text-center"
          >
            <div className="p-6 rounded-lg bg-card shadow-lg">
              <Code2 className="h-8 w-8 mx-auto mb-4 text-primary" />
              <h3 className="text-lg font-semibold mb-2">{t('features.design.title')}</h3>
              <p className="text-foreground/80">{t('features.design.description')}</p>
            </div>
            <div className="p-6 rounded-lg bg-card shadow-lg">
              <Rocket className="h-8 w-8 mx-auto mb-4 text-primary" />
              <h3 className="text-lg font-semibold mb-2">{t('features.performance.title')}</h3>
              <p className="text-foreground/80">{t('features.performance.description')}</p>
            </div>
            <div className="p-6 rounded-lg bg-card shadow-lg">
              <Sparkles className="h-8 w-8 mx-auto mb-4 text-primary" />
              <h3 className="text-lg font-semibold mb-2">{t('features.support.title')}</h3>
              <p className="text-foreground/80">{t('features.support.description')}</p>
            </div>
          </motion.div>
        </motion.div>
      </div>
    </div>
  );
}