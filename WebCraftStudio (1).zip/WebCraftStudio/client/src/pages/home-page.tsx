import { RequestForm } from "@/components/request-form";
import { HeroSection } from "@/components/hero-section";
import { Footer } from "@/components/footer";
import { Navbar } from "@/components/navbar";
import { motion } from "framer-motion";

export default function HomePage() {
  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <HeroSection />
      <motion.div 
        initial={{ opacity: 0 }}
        whileInView={{ opacity: 1 }}
        transition={{ duration: 0.8 }}
        viewport={{ once: true }}
        className="py-16"
      >
        <div className="relative container mx-auto px-4">
          <RequestForm />
        </div>
      </motion.div>
      <Footer />
    </div>
  );
}