import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';

const resources = {
  it: {
    translation: {
      "hero.title": "Leonard Design",
      "hero.subtitle": "Ciao! Sono uno sviluppatore web appassionato che trasforma le tue idee in realtà digitali.",
      "hero.description": "Specializzato nella creazione di siti web moderni e performanti che catturano l'essenza del tuo business.",
      "hero.cta": "Richiedi un Preventivo",
      "features.design.title": "Design Moderno",
      "features.design.description": "Interface eleganti e responsive per ogni dispositivo",
      "features.performance.title": "Performance",
      "features.performance.description": "Siti web veloci e ottimizzati per i motori di ricerca",
      "features.support.title": "Supporto Continuo",
      "features.support.description": "Assistenza dedicata per ogni tua necessità"
    }
  },
  en: {
    translation: {
      "hero.title": "Leonard Design",
      "hero.subtitle": "Hi! I'm a passionate web developer who turns your ideas into digital reality.",
      "hero.description": "Specialized in creating modern and performant websites that capture the essence of your business.",
      "hero.cta": "Request a Quote",
      "features.design.title": "Modern Design",
      "features.design.description": "Elegant and responsive interfaces for every device",
      "features.performance.title": "Performance",
      "features.performance.description": "Fast websites optimized for search engines",
      "features.support.title": "Continuous Support",
      "features.support.description": "Dedicated assistance for all your needs"
    }
  },
  es: {
    translation: {
      "hero.title": "Leonard Design",
      "hero.subtitle": "¡Hola! Soy un desarrollador web apasionado que convierte tus ideas en realidad digital.",
      "hero.description": "Especializado en crear sitios web modernos y eficientes que capturan la esencia de tu negocio.",
      "hero.cta": "Solicitar Presupuesto",
      "features.design.title": "Diseño Moderno",
      "features.design.description": "Interfaces elegantes y responsivas para cada dispositivo",
      "features.performance.title": "Rendimiento",
      "features.performance.description": "Sitios web rápidos y optimizados para motores de búsqueda",
      "features.support.title": "Soporte Continuo",
      "features.support.description": "Asistencia dedicada para todas tus necesidades"
    }
  }
};

i18n
  .use(initReactI18next)
  .init({
    resources,
    lng: "it",
    fallbackLng: "it",
    interpolation: {
      escapeValue: false
    }
  });

export default i18n;
